package HASH;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DonQuijoteDeLaMancha {
public static void main(String args[]) {
	try {
		FileOutputStream fileout = new FileOutputStream("DATOS.DAT");
		ObjectOutputStream dataOS = new ObjectOutputStream(fileout);
		MessageDigest md = MessageDigest.getInstance("SHA");
		String DATOS = "En un lugar de la Mancha de cuyo nombre no quiero acordarme,\n"
				+ "no ha mucho tiempo que vivía un hidalgo de los de lanza en\n"
				+ "astillero, adarga antigua, rocín flaco y galgo corredor. Una olla\n"
				+ "de algo más vaca que carnero, salpicón las noches, duelos y quebrantos\n"
				+ "los sábados, lentejas los viernes, algún palomino de añadidura\n"
				+ "los domingos, consumían las tres partes de su hacienda. El resto della\n"
				+ "concluían sayo de velarte, calzas de velludo para las fiestas con \n"
				+ "sus pantuflos de lo mismo, y los días de entresemana se honraba con su\n"
				+ "vellorí de lo más fino";
		
		byte dataBytes[] = DATOS.getBytes();
		md.update(dataBytes); 
		byte resumen[] = md.digest(); 
		dataOS.writeObject(DATOS);
		dataOS.writeObject(resumen);
		dataOS.close();
		fileout.close();
		
			System.out.println("DATOS:" + DATOS);
			System.out.println("\nRESUMEN CREADO CON ÉXITO");
			
	} catch (IOException e) {
		e.printStackTrace();
	} catch (NoSuchAlgorithmException e) {
		e.printStackTrace();
		
		}
	}
}
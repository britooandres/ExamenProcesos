package SEMAFORO;

public class Semaforo extends Thread {
	private String color;
	private int tiempo;
	private static Object lock = new Object();
	private static String ultimoColor = "VERDE";

	public Semaforo(String color, int tiempo) {
		this.color = color;
		this.tiempo = tiempo;
	}

	public void run() {
		try {
			while (true) {
				synchronized (lock) {
					while (!color.equals(ultimoColor)) {
						lock.wait();
					}
				}
				System.out.println("EL SEMAFORO DE COLOR " + color + " DURA " + tiempo / 1000 + " SEGUNDOS");
				Thread.sleep(tiempo);
				synchronized (lock) {
					if (color.equals("ROJO")) {
						ultimoColor = "VERDE";
					} else if (color.equals("VERDE")) {
						ultimoColor = "AMARILLO";
					} else if (color.equals("AMARILLO")) {
						ultimoColor = "ROJO";
					}
					lock.notifyAll();
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Semaforo ROJO = new Semaforo("ROJO", 5000);
		Semaforo AMARILLO = new Semaforo("AMARILLO", 2000);
		Semaforo VERDE = new Semaforo("VERDE", 4000);
		ROJO.start();
		AMARILLO.start();
		VERDE.start();
	}
}